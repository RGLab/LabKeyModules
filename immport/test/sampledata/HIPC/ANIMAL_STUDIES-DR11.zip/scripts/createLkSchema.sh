#!/bin/bash

if [ $# != 4 ]
  then
    echo ""
    echo "Usage: createLkSchema.sh Host, User, Password, Database"
    echo ""
    exit 1
fi

HOST=$1
USER=$2
PASSWORD=$3
DATABASE=$4

CMD="mysql -h $HOST -u $USER -p$PASSWORD $DATABASE"

echo "Creating lk_adverse_event_severity"
$CMD < ../schema/lk_adverse_event_severity.ddl

echo "Creating lk_age_event"
$CMD < ../schema/lk_age_event.ddl

echo "Creating lk_allele_status"
$CMD < ../schema/lk_allele_status.ddl

echo "Creating lk_data_completeness"
$CMD < ../schema/lk_data_completeness.ddl

echo "Creating lk_date_format"
$CMD < ../schema/lk_data_format.ddl

echo "Creating lk_ethnicity"
$CMD < ../schema/lk_ethnicity.ddl

echo "Creating lk_exon_intron_interrogated"
$CMD < ../schema/lk_exon_intron_interrogated.ddl

echo "Creating lk_experiment_purpose"
$CMD < ../schema/lk_experiment_purpose.ddl

echo "Creating lk_exp_measurement_tech"
$CMD < ../schema/lk_exp_measurement_tech.ddl

echo "Creating lk_expsample_result_schema"
$CMD < ../schema/lk_expsample_result_schema.ddl

echo "Creating lk_feature_location"
$CMD < ../schema/lk_feature_location.ddl

echo "Creating lk_feature_sequence_type"
$CMD < ../schema/lk_feature_sequence_type.ddl

echo "Creating lk_feature_strand"
$CMD < ../schema/lk_feature_strand.ddl

echo "Creating lk_feature_type"
$CMD < ../schema/lk_feature_type.ddl

echo "Creating lk_file_detail"
$CMD < ../schema/lk_file_detail.ddl

echo "Creating lk_file_purpose"
$CMD < ../schema/lk_file_purpose.ddl

echo "Creating lk_gender"
$CMD < ../schema/lk_gender.ddl

echo "Creating lk_locus_name"
$CMD < ../schema/lk_locus_name.ddl

echo "Creating lk_locus_typing_method"
$CMD < ../schema/lk_locus_typing_method.ddl

echo "Creating lk_personnel_role"
$CMD < ../schema/lk_personnel_role.ddl

echo "Creating lk_plate_type"
$CMD < ../schema/lk_plate_type.ddl

echo "Creating lk_protocol_type"
$CMD < ../schema/lk_protocol_type.ddl

echo "Creating lk_public_repository"
$CMD < ../schema/lk_public_repository.ddl

echo "Creating lk_race"
$CMD < ../schema/lk_race.ddl

echo "Creating lk_reagent_type"
$CMD < ../schema/lk_reagent_type.ddl

echo "Creating lk_reason_not_completed"
$CMD < ../schema/lk_reason_not_completed.ddl

echo "Creating lk_research_focus"
$CMD < ../schema/lk_research_focus.ddl

echo "Creating lk_sample_type"
$CMD < ../schema/lk_sample_type.ddl

echo "Creating lk_source_type"
$CMD < ../schema/lk_source_type.ddl

echo "Creating lk_species"
$CMD < ../schema/lk_species.ddl

echo "Creating lk_study_file_type"
$CMD < ../schema/lk_study_file_type.ddl

echo "Creating lk_study_panel"
$CMD < ../schema/lk_study_panel.ddl

echo "Creating lk_study_type"
$CMD < ../schema/lk_study_type.ddl

echo "Creating lk_t0_event"
$CMD < ../schema/lk_t0_event.ddl

echo "Creating lk_time_unit"
$CMD < ../schema/lk_time_unit.ddl

echo "Creating lk_unit_of_measure"
$CMD < ../schema/lk_unit_of_measure.ddl
