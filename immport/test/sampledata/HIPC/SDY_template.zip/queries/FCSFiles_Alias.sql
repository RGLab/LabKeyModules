SELECT
 FCSFiles.Name AS "File Info Name"
FROM
 FCSFiles
